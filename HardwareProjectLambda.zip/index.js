const MongoClient = require('mongodb').MongoClient;

exports.handler = async (event, context) => {
  const uri = "mongodb+srv://ekillalea:Cuddles00@clubcluster.phertpf.mongodb.net/?retryWrites=true&w=majority";
  const client = new MongoClient(uri, 
    { 
      useNewUrlParser: true, 
      useUnifiedTopology: true 
    });
  
  try {
    await client.connect();
    console.log("Connected to MongoDB cluster");
    
    let fingerLog = JSON.stringify(event, null, 2);
    console.log("Event1", fingerLog);
    const response = {
        body: JSON.stringify(fingerLog),
    };
    
    const database = client.db("club_students");
    const collection = database.collection("attendance");
    
    const entry = fingerLog;
    const result = await collection.insertOne(entry);
    console.log("Inserted entry into the collection");
    
    return response;
    
  } catch (e) {
    console.error(e);
  } finally {
    await client.close();
    console.log("Connection to MongoDB cluster closed");
  }
};